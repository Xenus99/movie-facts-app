import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { email, name, image, favorite } = body;

    if (!email) {
      return NextResponse.json({ error: 'Missing email' }, { status: 400 });
    }

    // If favorite is provided, update or create entry
    if (favorite) {
      const user = await prisma.userMovie.upsert({
        where: { email },
        update: { favorite },
        create: { email, name, image, favorite },
      });
      return NextResponse.json({ message: 'Movie saved' }, { status: 200 });
    } else {
      // Check if user exists (e.g. first time login)
      const existing = await prisma.userMovie.findUnique({
        where: { email },
      });

      // If not found, return 204 (used to trigger movie prompt)
      if (!existing) {
        return new NextResponse(null, { status: 204 });
      } else {
        return NextResponse.json({ message: 'User exists' }, { status: 200 });
      }
    }
  } catch (err) {
    console.error('Save movie error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
